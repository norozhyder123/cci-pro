@extends('layouts.home')
@section('content')
        <section class="page_banner">
            <h3 class="heading_3 position-relative">Contact Us</h3>
        </section>
        <section>
            <div class="contact-form-wrapper ">
                <form action="#" class="contact-form mx-auto">
                    <h5 class="heading_3 text-center mb-4">Contact Us</h5>
                    <p class="paragraph_medium text-center mb-3">
                        Got any questions? Submit your query and our representatives will get back to you at the earliest!
                    </p>
                    <div>
                        <input type="text" class="form-control rounded mb-3 form-input" id="name" placeholder="Name" required>
                    </div>
                    <div>
                        <input type="email" class="form-control rounded mb-3 form-input" placeholder="Email" required>
                    </div>
                    <div>
                        <textarea id="message" class="form-control rounded mb-3 form-text-area" rows="5" cols="30" placeholder="Message" required></textarea>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button class="green_btn">Send</button>
                    </div>
                </form>
            </div>
        </section>
@endsection
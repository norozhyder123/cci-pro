@extends('layouts.dashboard')
@section('content')
<div class="col-lg-6 col-md-12 col-sm-12 ps-3">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="text_size-24 font_weight--500">Daily Stock Update</div>
                            <div class="paragraph_medium text_color--green font_weight--500">Expand</div>
                        </div>
                        <div class="stock_update mb-3">
                            <div class="row carousel_update">
                                <div class="col single_block mx-2">
                                    <div class="text_size-12 mb-2">NASDAQ Composite Index</div>
                                    <img class="w-100" src="./assets/images/update_img1.png" alt="">
                                </div>
                                <div class="col single_block mx-2">
                                    <div class="text_size-12 mb-2">NASDAQ-100</div>
                                    <img class="w-100" src="./assets/images/update_img1.png" alt="">
                                </div>
                                <div class="col single_block mx-2">
                                    <div class="text_size-12 mb-2">ZB JUN 2022</div>
                                    <img class="w-100" src="./assets/images/update_img2.png" alt="">
                                </div>
                                <div class="col single_block mx-2">
                                    <div class="text_size-12 mb-2">ZB JUN 2022</div>
                                    <img class="w-100" src="./assets/images/update_img2.png" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="text_size-24 font_weight--500 mb-3">Investment Calculator</div>
                        <div class="invest_cal mb-3">
                            <form action="">
                                <div class="d-flex mb-4">
                                    <div>
                                        <label class="cal_label">Starting Amount</label>
                                        <input type="text" class="cal_input w-90" placeholder="$">
                                    </div>
                                    <div>
                                        <label class="cal_label">After</label>
                                        <input type="text" class="cal_input w-90" placeholder="Years">
                                    </div>
                                    <div>
                                        <label class="cal_label">Select Industry to invest in</label>
                                        <select class="cal_input" aria-label="Default select example">
                                            <option selected>Choose an industry</option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                            <option value="3">Three</option>
                                          </select>
                                    </div>
                                </div>
                                <div class="d-flex mb-4">
                                    <div class="w-30">
                                        <label class="cal_label">Return Rate</label>
                                        <input type="text" class="cal_input w-90" placeholder="%">
                                    </div>
                                    <div class="w-30">
                                        <label class="cal_label">Compound</label>
                                        <input type="text" class="cal_input w-90" placeholder="Annually">
                                    </div>
                                </div>
                                <div class="float-end">
                                    <button class="calculate_btn ">Calculate</button>
                                </div>
                            </form>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="text_size-24 font_weight--500">Real Estate Listings</div>
                            <div class="paragraph_medium text_color--green font_weight--500">Expand</div>
                        </div>
                        <div class="mb-3">
                            <div class="row carousel_estate">
                                <div class="col single_state mx-2">
                                    <img class="w-100" src="./assets/images/blog_1-img.png" alt="">
                                    <div class="p-2">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div class="text_size-14 text_color--green">Listing 01</div>
                                            <div class="text_size-12 text_color--green">$1000.00</div>
                                        </div>
                                        <div class="d-flex justify-content-between mb-2">
                                            <div class="text_size-12">ABC RD, 1234,<br> XYZ 82021</div>
                                            <div class="text_size-12">Min $200.00</div>
                                        </div>
                                        <div class="mb-2">
                                            <button class="evaluate_btn">Evaluate</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col single_state mx-2">
                                    <img class="w-100" src="./assets/images/blog_1-img.png" alt="">
                                    <div class="p-2">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div class="text_size-14 text_color--green">Listing 01</div>
                                            <div class="text_size-12 text_color--green">$1000.00</div>
                                        </div>
                                        <div class="d-flex justify-content-between mb-2">
                                            <div class="text_size-12">ABC RD, 1234,<br> XYZ 82021</div>
                                            <div class="text_size-12">Min $200.00</div>
                                        </div>
                                        <div class="mb-2">
                                            <button class="evaluate_btn">Evaluate</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col single_state mx-2">
                                    <img class="w-100" src="./assets/images/blog_1-img.png" alt="">
                                    <div class="p-2">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div class="text_size-14 text_color--green">Listing 01</div>
                                            <div class="text_size-12 text_color--green">$1000.00</div>
                                        </div>
                                        <div class="d-flex justify-content-between mb-2">
                                            <div class="text_size-12">ABC RD, 1234,<br> XYZ 82021</div>
                                            <div class="text_size-12">Min $200.00</div>
                                        </div>
                                        <div class="mb-2">
                                            <button class="evaluate_btn">Evaluate</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col single_state mx-2">
                                    <img class="w-100" src="./assets/images/blog_1-img.png" alt="">
                                    <div class="p-2">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div class="text_size-14 text_color--green">Listing 01</div>
                                            <div class="text_size-12 text_color--green">$1000.00</div>
                                        </div>
                                        <div class="d-flex justify-content-between mb-2">
                                            <div class="text_size-12">ABC RD, 1234,<br> XYZ 82021</div>
                                            <div class="text_size-12">Min $200.00</div>
                                        </div>
                                        <div class="mb-2">
                                            <button class="evaluate_btn">Evaluate</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
</div>
<div class="col-lg-3 col-md-12 col-sm-12 px-0">
                        <div>
                            <div class="forum_right font_family--kanit mb-3">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <div class="text_size-24 text_color--green">Forums</div>
                                    <div class="paragraph_medium text_color--green">View All</div>
                                </div>
                                <div class="single_forum">
                                    <div class="text_size-14 text_color--green mb-2">
                                        John Alsvin asked
                                    </div>
                                    <div class="text_size-16">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
                                    </div>
                                    <div class="text_size-14 font_weight--300">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata
                                        sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
                                        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet
                                    </div>
                                    <div class="text_size-14 text_color--green mb-2">
                                        John Alsvin asked
                                    </div>
                                    <div class="text_size-16">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
                                    </div>
                                    <div class="text_size-14 font_weight--300">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata
                                        sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
                                        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet
                                    </div>
                                    <div class="text_size-14 text_color--green mb-2">
                                        John Alsvin asked
                                    </div>
                                    <div class="text_size-16">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
                                    </div>
                                    <div class="text_size-14 font_weight--300">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata
                                        sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
                                        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet
                                    </div>
                                </div>
                            </div>
                            <div class="forum_right font_family--kanit">
                                <div class="d-flex align-items-center justify-content-between mb-4">
                                    <div class="text_size-24 text_color--green">Latest News &<br>Updates</div>
                                    <div class="paragraph_medium text_color--green">View All</div>
                                </div>
                                <div class="single_forum">
                                    <div class="d-flex mb-2 font_weight--300">
                                        <img class="blog_img me-2" src="./assets/images/blog_1-img.png" alt="">
                                        <div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex mb-2 font_weight--300">
                                        <img class="blog_img me-2" src="./assets/images/blog_2-img.png" alt="">
                                        <div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex mb-2 font_weight--300">
                                        <img class="blog_img me-2" src="./assets/images/blog_3-img.png" alt="">
                                        <div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
</div>
@endsection

<?php $__env->startSection('content'); ?>
<div class="col-lg-6 col-md-12 col-sm-12 ps-3">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="text_size-24 font_weight--500">Notifications</div>
                            <div class="paragraph_medium text_color--green font_weight--500">Mark all as read</div>
                        </div>
                        <div class="notification_wrapper">
                            <div class="single_notification mb-2">
                                <img class="me-2" src="./assets/images/person_placeholder.png" alt="">
                                <div class="me-2">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div class="text_size-14 font_weight--500">DAILY STOCKS</div>
                                        <div class="text_size-12 font_weight--500">21 FEB 2022 • 11:54 PM</div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div class="text_size-14 me-2">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut aliquip ex ea commodo consequat.
                                        </div>
                                        <!-- <div class="d-flex">
                                            <img class="me-2" src="./assets/images/Icon-Close Square.png" alt="">
                                            <img class="" src="./assets/images/Icon-Tick Square.png" alt="">
                                        </div> -->
                                    </div>
                                </div>
                                <div>
                                    <img class="" src="./assets/images/Iconly-More Black.png" alt="">
                                </div>
                            </div>
                            <div class="single_notification mb-2">
                                <img class="me-2" src="./assets/images/person_placeholder.png" alt="">
                                <div class="me-2">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div class="text_size-14 font_weight--500">DAILY STOCKS</div>
                                        <div class="text_size-12 font_weight--500">21 FEB 2022 • 11:54 PM</div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="text_size-14 me-2">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut aliquip ex ea commodo consequat.
                                        </div>
                                        <div class="d-flex">
                                            <img class="me-2" src="./assets/images/Icon-Close Square.png" alt="">
                                            <img class="" src="./assets/images/Icon-Tick Square.png" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <img class="" src="./assets/images/Iconly-More Black.png" alt="">
                                </div>
                            </div>
                            <div class="single_notification mb-2">
                                <img class="me-2" src="./assets/images/person_placeholder.png" alt="">
                                <div class="me-2">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div class="text_size-14 font_weight--500">DAILY STOCKS</div>
                                        <div class="text_size-12 font_weight--500">21 FEB 2022 • 11:54 PM</div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div class="text_size-14 me-2">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut aliquip ex ea commodo consequat.
                                        </div>
                                        <!-- <div class="d-flex">
                                            <img class="me-2" src="./assets/images/Icon-Close Square.png" alt="">
                                            <img class="" src="./assets/images/Icon-Tick Square.png" alt="">
                                        </div> -->
                                    </div>
                                </div>
                                <div>
                                    <img class="" src="./assets/images/Iconly-More Black.png" alt="">
                                </div>
                            </div>
                            <div class="single_notification mb-2">
                                <img class="me-2" src="./assets/images/person_placeholder.png" alt="">
                                <div class="me-2">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div class="text_size-14 font_weight--500">DAILY STOCKS</div>
                                        <div class="text_size-12 font_weight--500">21 FEB 2022 • 11:54 PM</div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div class="text_size-14 me-2">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut aliquip ex ea commodo consequat.
                                        </div>
                                        <!-- <div class="d-flex">
                                            <img class="me-2" src="./assets/images/Icon-Close Square.png" alt="">
                                            <img class="" src="./assets/images/Icon-Tick Square.png" alt="">
                                        </div> -->
                                    </div>
                                </div>
                                <div>
                                    <img class="" src="./assets/images/Iconly-More Black.png" alt="">
                                </div>
                            </div>
                            <div class="single_notification mb-2">
                                <img class="me-2" src="./assets/images/person_placeholder.png" alt="">
                                <div class="me-2">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div class="text_size-14 font_weight--500">DAILY STOCKS</div>
                                        <div class="text_size-12 font_weight--500">21 FEB 2022 • 11:54 PM</div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="text_size-14 me-2">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut aliquip ex ea commodo consequat.
                                        </div>
                                        <div class="d-flex">
                                            <img class="me-2" src="./assets/images/Icon-Close Square.png" alt="">
                                            <img class="" src="./assets/images/Icon-Tick Square.png" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <img class="" src="./assets/images/Iconly-More Black.png" alt="">
                                </div>
                            </div>
                            <div class="single_notification mb-2">
                                <img class="me-2" src="./assets/images/person_placeholder.png" alt="">
                                <div class="me-2">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div class="text_size-14 font_weight--500">DAILY STOCKS</div>
                                        <div class="text_size-12 font_weight--500">21 FEB 2022 • 11:54 PM</div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div class="text_size-14 me-2">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut aliquip ex ea commodo consequat.
                                        </div>
                                        <!-- <div class="d-flex">
                                            <img class="me-2" src="./assets/images/Icon-Close Square.png" alt="">
                                            <img class="" src="./assets/images/Icon-Tick Square.png" alt="">
                                        </div> -->
                                    </div>
                                </div>
                                <div>
                                    <img class="" src="./assets/images/Iconly-More Black.png" alt="">
                                </div>
                            </div>
                            <div class="single_notification mb-2">
                                <img class="me-2" src="./assets/images/person_placeholder.png" alt="">
                                <div class="me-2">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div class="text_size-14 font_weight--500">DAILY STOCKS</div>
                                        <div class="text_size-12 font_weight--500">21 FEB 2022 • 11:54 PM</div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div class="text_size-14 me-2">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut aliquip ex ea commodo consequat.
                                        </div>
                                        <!-- <div class="d-flex">
                                            <img class="me-2" src="./assets/images/Icon-Close Square.png" alt="">
                                            <img class="" src="./assets/images/Icon-Tick Square.png" alt="">
                                        </div> -->
                                    </div>
                                </div>
                                <div>
                                    <img class="" src="./assets/images/Iconly-More Black.png" alt="">
                                </div>
                            </div>
                            <div class="single_notification mb-2">
                                <img class="me-2" src="./assets/images/person_placeholder.png" alt="">
                                <div class="me-2">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div class="text_size-14 font_weight--500">DAILY STOCKS</div>
                                        <div class="text_size-12 font_weight--500">21 FEB 2022 • 11:54 PM</div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div class="text_size-14 me-2">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut aliquip ex ea commodo consequat.
                                        </div>
                                        <!-- <div class="d-flex">
                                            <img class="me-2" src="./assets/images/Icon-Close Square.png" alt="">
                                            <img class="" src="./assets/images/Icon-Tick Square.png" alt="">
                                        </div> -->
                                    </div>
                                </div>
                                <div>
                                    <img class="" src="./assets/images/Iconly-More Black.png" alt="">
                                </div>
                            </div>
                        </div>
</div>
<div class="col-lg-3 col-md-12 col-sm-12 px-0">
                        <div>
                            <div class="forum_right font_family--kanit mb-3">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <div class="text_size-24 text_color--green">Forums</div>
                                    <div class="paragraph_medium text_color--green">View All</div>
                                </div>
                                <div class="single_forum">
                                    <div class="text_size-14 text_color--green mb-2">
                                        John Alsvin asked
                                    </div>
                                    <div class="text_size-16">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
                                    </div>
                                    <div class="text_size-14 font_weight--300">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata
                                        sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
                                        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet
                                    </div>
                                    <div class="text_size-14 text_color--green mb-2">
                                        John Alsvin asked
                                    </div>
                                    <div class="text_size-16">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
                                    </div>
                                    <div class="text_size-14 font_weight--300">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata
                                        sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
                                        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet
                                    </div>
                                    <div class="text_size-14 text_color--green mb-2">
                                        John Alsvin asked
                                    </div>
                                    <div class="text_size-16">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt
                                    </div>
                                    <div class="text_size-14 font_weight--300">
                                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata
                                        sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et
                                        accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet
                                    </div>
                                </div>
                            </div>
                            <div class="forum_right font_family--kanit">
                                <div class="d-flex align-items-center justify-content-between mb-4">
                                    <div class="text_size-24 text_color--green">Latest News &<br>Updates</div>
                                    <div class="paragraph_medium text_color--green">View All</div>
                                </div>
                                <div class="single_forum">
                                    <div class="d-flex mb-2 font_weight--300">
                                        <img class="blog_img me-2" src="./assets/images/blog_1-img.png" alt="">
                                        <div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex mb-2 font_weight--300">
                                        <img class="blog_img me-2" src="./assets/images/blog_2-img.png" alt="">
                                        <div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex mb-2 font_weight--300">
                                        <img class="blog_img me-2" src="./assets/images/blog_3-img.png" alt="">
                                        <div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                            <div class="text_size-16">
                                                Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
</div>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\CII\resources\views/front/notifications.blade.php ENDPATH**/ ?>
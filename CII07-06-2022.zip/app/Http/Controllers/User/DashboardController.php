<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserRequest;
use App\Models\User;
use App\Models\User\Blog;
use Auth;

class DashboardController extends Controller
{
    //
    public function index()
    {
    	$blogs = UserRequest::has('user')->with(['user' =>function($conn){
    		$conn->has('blogs');
    	}])->where('user_id', Auth::user()->id)->get();
    	// $blogs->load('user');
    	// $blogs->load('blogs');
    	// $details = Auth::user()->education()->get();
    	// dd($blogs);
    	// dd($blogs[0]->user);
    	return view('user.dashboard.dashboard', compact('blogs'));
    	# code...
    }

    public function Timeline()
    {
    	$blogs = UserRequest::has('user')->with(['user' =>function($conn){
    		$conn->has('blogs')->with(['blogs']);
    	}])->where('user_id', Auth::user()->id)->get();

    	$posts = UserRequest::has('user')->with(['user' =>function($conn){
    		$conn->has('posts')->with(['posts']);
    	}])->where('user_id', Auth::user()->id)->get();

    	// dd($posts);
    	return view('user.dashboard.timeline', compact('blogs','posts'));
    	# code...
    }
}

<?php

namespace App\Http\Controllers\User;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use App\Models\User\UserProfileDetail;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\File;
use App\Models\User;
use App\Models\Image;
use Hash;
use Auth;

class UserController extends Controller
{
    public function index()
    {
    	return redirect()->route('admin.dashboard');
    	# code...
    }

    public function Show()
    {
    	$id = Auth::user()->id;
    	$users = User::findOrFail($id);
        // $users->load('education');
        // dd($users->imageable);
    	return view('user.profile', compact('users'));
    	# code...
    }

    public function Update($id, Request $request, User $user)
    {
    	$id = Auth::user()->id;
    	$user = $user->findOrFail($id);
    	
    	if($request->email != $user->email){

	    	$validate = $this->validator($request->all());
	    	if($validate->fails()){
	    		return redirect()->back()->withErrors($validate)->withInput();
	    	}
    	}

    	if($request->password){

            $validate = Validator::make($request->all(), [
            'old_password' => ['required', 'string', 'min:6'],
            ]);
            if($validate->fails()){
                return redirect()->back()->withErrors($validate)->withInput();
            }

            if (!Hash::check($request->old_password, $user->password)) {
                
                return redirect()->back()->withErrors(['password'=>'Your Old password didn\'t match'] )->withInput();
            }else{
                $user->password = Hash::make($request->password);
            }
        }

        if($request->hasFile('profile_img')){
            $extension = $request->file('profile_img')->extension();
            $name = Auth::user()->first_name.time().'.'.$extension;

            $path = Storage::disk('public')->putFileAs('profiles', $request->file('profile_img'), $name);
            // $path = $request->file('profile_img')->store('public/profiles');
            $image = new Image;
            $image->filename = $path;
            $image->user_id = $id;
            $user->images()->save($image);

            $user->profile_img = $path;
        }

    	$user->first_name = $request->first_name;
    	$user->last_name = $request->last_name;
    	$user->email = $request->email;
    	$user->phone = $request->phone;
    	$user->country = $request->country;
    	$user->city = $request->city;
    	$user->state = $request->state;
    	$user->zip_code = $request->zip_code;
    	$user->save();

    	return redirect()->back()->with('message' , 'Record Updated Successfully');
    	# code...
    }

    public function AddEducation(Request $request)
    {
        $id = Auth::user()->id;
        $validate = Validator::make($request->all(), [
                        'degree_title' => 'required',
                        'degree_name' => 'required',
                        'college_name' => 'required'
                    ]);
        if($validate->fails())
        {
            return response()->json(['message' => 'Fill all the fields '], 404);
        }

        $education = new UserProfileDetail;
        $education->degree_title = $request->degree_title;
        $education->degree_name = $request->degree_name;
        $education->name = $request->college_name;
        $education->position = $request->position;
        $education->address = empty($request->edu_address)?'':$request->edu_address;
        $education->country = empty($request->edu_country)?'':$request->edu_country;
        $education->state = empty($request->edu_state)?'':$request->edu_state;
        $education->city = empty($request->edu_city)?'':$request->edu_city;
        $education->zipcode = empty($request->edu_zipcode)?'':$request->edu_zipcode;
        $education->type = $request->type;
        $education->user_id = $id;
        Auth::user()->education()->save($education);
        $education->save();

        return response()->json(['message' => 'Successfully Added','eduId' => $education->id, 'education' => $education], 200);

        // dd($request->all());
        # code...
    }

    public function UpdateEducation(Request $request, $id, $eduId)
    {
        $education = UserProfileDetail::find($eduId);
        $education->degree_title = $request->degree_title;
        $education->degree_name = $request->degree_name;
        $education->name = $request->college_name;
        $education->position = $request->position;
        $education->address = empty($request->edu_address)?'':$request->edu_address;
        $education->country = empty($request->edu_country)?'':$request->edu_country;
        $education->state = empty($request->edu_state)?'':$request->edu_state;
        $education->city = empty($request->edu_city)?'':$request->edu_city;
        $education->zipcode = empty($request->edu_zipcode)?'':$request->edu_zipcode;
        $education->type = $request->type;
        $education->save();

        return response()->json(['message' => 'Successfully Added','eduId' => $education->id, 'education' => $education], 200);
        // dd($eduId);
        # code...
    }
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'numeric'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
        ]);
    }
}

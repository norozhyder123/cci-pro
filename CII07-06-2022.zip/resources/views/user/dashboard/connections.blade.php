@extends('layouts.dashboard')
@section('content')
<div class="col-lg-9 col-md-12 col-sm-12 ps-3">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <div class="text_size-24 font_weight--500">Connections</div>
    </div>
    <div class="mb-3 you_know ms-2 p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="text_size-16 font_weight--500">People you may know</div>
        </div>
        <div class="row people_you-know justify-content-start mb-2">
            @foreach($connections as $connection)
            <div class="col-3 connectivity px-0 m-2">
                @if(!empty($connection->profile_img))
                <img src="{{asset('storage/'.$connection->profile_img)}}" class="w-100" alt="">
                @else
                <img src="{{asset('assets/images/person_1.png')}}" class="w-100" alt="">
                @endif

                <div class="d-flex justify-content-between align-items-center px-2 my-2 w-100">
                    <div class="text_size-12">{{$connection->first_name.' '.$connection->last_name}}</div>
                    <img src="{{asset('assets/images/Iconly-Bulk-Send.png')}}" alt="" data-url="{{ route('send.request', $connection->id) }}" onclick="sendRequest({{ $connection->id }}, this)">
                </div>
                <div class="text_size-12 font_color-black font_weight--300 px-2 mb-3">
                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                </div>
                <a class="green_profile-btn text-center" href="{{ route('connectionProfile', $connection->id) }}">View Profile</a>
            </div>
            @endforeach
        </div>
    </div>
    <div class="mb-3 you_know ms-2 p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="text_size-16 font_weight--500">My Connections</div>
        </div>
        <div class="row people_you-know justify-content-start mb-2">
            @foreach($connected as $connect)
            <div class="col-3 connectivity px-0 m-2">
                @if(!empty($connect->profile_img))
                <img src="{{asset('storage/'.$connect->profile_img)}}" class="w-100" alt="">
                @else
                <img src="{{asset('assets/images/person_1.png')}}" class="w-100" alt="">
                @endif
                    <div class="p-2">
                        <div class="text_size-12">{{$connect->first_name.' '.$connect->last_name}}</div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center px-2 my-2 w-100">
                        @php
                            $req_status = App\Models\UserRequest::select('status as requestStatus')->where('user_id', $connect->id)->orWhere('to_id', $connect->id)->first();
                            @endphp
                    @if($req_status->requestStatus == 'waiting')
                    <small class="text-capitalize">Waiting For Approval</small>
                    @else
                    <small class="text-capitalize">{{$req_status->requestStatus}}</small>
                    @endif
                </div>
                <div class="text_size-12 font_color-black font_weight--300 px-2 mb-3">
                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                </div>
                <button class="green_profile-btn">View Profile</button>
            </div>
            @endforeach
        </div>
    </div>

    <div class="mb-3 you_know ms-2 p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="text_size-16 font_weight--500">My Incoming Requests</div>
        </div>
        <div class="row people_you-know justify-content-start mb-2">
            @foreach($requests as $connect)
            <div class="col-3 connectivity px-0 m-2">
                @if(!empty($connect->profile_img))
                <img src="{{asset('storage/'.$connect->profile_img)}}" class="w-100" alt="">
                @else
                <img src="{{asset('assets/images/person_1.png')}}" class="w-100" alt="">
                @endif
                <div class="p-2">
                    <div class="text_size-12">{{$connect->first_name.' '.$connect->last_name}}</div>
                </div>
                    <div class="d-flex justify-content-between align-items-center px-2 my-2 w-100">
                    @if($connect->requestStatus == 'waiting')
                    <button class="green_profile-btn" data-url="{{ route('approve.request', $connect->id) }}" onclick="approveRequest({{ $connect->id }}, this)">Approve</button>
                    <button class="green_profile-btn" data-url="{{ route('reject.request', $connect->id) }}" onclick="rejectRequest({{ $connect->id }}, this)">Reject</button>

                    @else
                    <small>{{$connect->requestStatus}}</small>
                    @endif
                </div>
                <div class="text_size-12 font_color-black font_weight--300 text-center px-2 mb-3">
                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                </div>
                <button class="green_profile-btn">View Profile</button>
            </div>
            @endforeach
        </div>
    </div>
</div>

<script>
    function sendRequest(id, data) {
        $.ajax({
                url: `${$(data).attr('data-url')}`,
                type: 'GET',
                data: {
                    from_id: id
                },
            })
            .done(function(resp) {
                $(data).parents('.connectivity').remove();
                console.log(resp);
                console.log("success");
            })
            .fail(function() {
                console.log("error");
            })
            .always(function() {
                console.log("complete");
            });

    }

    function approveRequest(id, data) {
        $.ajax({
                url: `${$(data).attr('data-url')}`,
                type: 'GET',
                data: {
                    from_id: id
                },
            })
            .done(function(resp) {
                $(data).parents('.connectivity').remove();
                console.log(resp);
                console.log("success");
            })
            .fail(function() {
                console.log("error");
            })
            .always(function() {
                console.log("complete");
            });

    }

    function rejectRequest(id, data) {
        $.ajax({
                url: `${$(data).attr('data-url')}`,
                type: 'GET',
                data: {
                    from_id: id
                },
            })
            .done(function(resp) {
                $(data).parents('.connectivity').remove();
                console.log(resp);
                console.log("success");
            })
            .fail(function() {
                console.log("error");
            })
            .always(function() {
                console.log("complete");
            });

    }
</script>
@endsection
@extends('layouts.dashboard')
@section('content')
<style>
.nav-tabs>li{
    margin: 0;
}
.fade:not(.show) {
    display: none;
}
.education_posi{
    position: absolute;
    top: 40px;
    left: 45px;
    text-transform: uppercase;
}
/*.education_detail{
    position: absolute;
    top: 50px;
    left: 45px;
    text-transform: uppercase;
}*/
.education_detail {
    margin-left: 30px !important;
    display: block;
    margin-top: 20px !important;
}
</style>
<div class="col-lg-9 col-md-12 col-sm-12 ps-3">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <div class="text_size-24 font_weight--500">Welcome {{ Auth::user()->first_name.' '.Auth::user()->last_name }}</div>
    </div>
    <div class="stock_update mb-3">
        <div class="align-items-center justify-content-between mb-3">
            <ul class="nav nav-tabs mb-3" id="ex1" role="tablist">
              <li class="nav-item" role="presentation">
                <a class="nav-link active" id="ex1-tab-1" data-mdb-toggle="tab" href="#ex1-tabs-1" role="tab" aria-controls="ex1-tabs-1" aria-selected="true">Personal Basic</a>
              </li>
              <li class="nav-item" role="presentation">
                <a class="nav-link" id="ex1-tab-2" data-mdb-toggle="tab" href="#ex1-tabs-2" role="tab" aria-controls="ex1-tabs-2" aria-selected="false" >Security</a>
              </li>
              <li class="nav-item" role="presentation">
                <a class="nav-link" id="ex1-tab-3" data-mdb-toggle="tab" href="#ex1-tabs-3" role="tab" aria-controls="ex1-tabs-3" aria-selected="false" >Details</a>
              </li>
            </ul>
        </div>
        <div class="tab-content" id="ex1-content">
            <form action="{{ route('profile.update',['id' => $users->id]) }}" method="post" enctype="multipart/form-data"  autocomplete="off">
                    @csrf
                    @if ($errors->any())
                    @foreach ($errors->all() as $error)
                    <p class="text-danger">{{$error}}</p>
                    @endforeach
                    @endif
                    @if(session()->has('message'))
                    <p class="text-success">
                        {{ session()->get('message') }}
                    </p>
                    @endif
                <div class="tab-pane fade show active" id="ex1-tabs-1" role="tabpanel" aria-labelledby="ex1-tab-1">
                    <h4>Basic Profile:</h4>
                    <fieldset class="form-group">
                        <label for="exampleInputfirstName">First Name</label>
                        <input type="text" class="form-control" id="exampleInputfirstName" placeholder="Enter email" value="{{ $users->first_name }}" name="first_name" required="">
                    </fieldset>
                    <fieldset class="form-group">
                        <label for="exampleInputlastName">Last Name</label>
                        <input type="text" class="form-control" id="exampleInputlastName" placeholder="Enter email" value="{{ $users->last_name }}" name="last_name" required="">
                    </fieldset>
                    <fieldset class="form-group">
                        <label for="exampleInputEmail1">Email address</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" value="{{ $users->email }}" name="email" required="">
                        <small class="text-muted">We'll never share your email with anyone else.</small>
                    </fieldset>
                    <fieldset class="form-group">
                        <label for="exampleInputphone">Phone</label>
                        <input type="text" class="form-control" id="exampleInputphone" placeholder="Enter Phone" value="{{ $users->phone }}" name="phone">
                        <small class="text-muted">We'll never share your phone with anyone else.</small>
                    </fieldset>
                    <fieldset class="form-group">
                        <label for="exampleInputlastdob">Date of Birth</label>
                        <input type="date" class="form-control" id="exampleInputlastdob" placeholder="Enter DOB" value="{{ $users->date_of_birth }}" name="date_of_birth" required="">
                    </fieldset>
                    <!-- <fieldset class="form-group">
                        <label for="exampleSelect1">Status</label>
                        <select class="form-control color-black" id="eexampleSelect11" name="status">
                            <option value="active" {{ $users->status == 'active'?'selected':'' }}>Active</option>
                            <option value="pending" {{ $users->status == 'pending'?'selected':'' }}>Pending</option>
                            <option value="inactive" {{ $users->status == 'inactive'?'selected':'' }}>Inactive</option>
                            <option value="suspended" {{ $users->status == 'suspended'?'selected':'' }}>Suspend</option>
                        </select>
                    </fieldset> -->
                    <fieldset class="form-group">
                        <label for="exampleInputstate">State</label>
                        <input type="text" class="form-control" id="exampleInputstate" placeholder="Enter State" value="{{ $users->state }}" name="state">
                    </fieldset>
                    <fieldset class="form-group">
                        <label for="exampleInputcountry">Country</label>
                        <input type="text" class="form-control" id="exampleInputcountry" placeholder="Enter Country" value="{{ $users->country }}" name="country">
                    </fieldset>
                    <fieldset class="form-group">
                        <label for="exampleInputcity">City</label>
                        <input type="text" class="form-control" id="exampleInputcity" placeholder="Enter City" value="{{ $users->city }}" name="city">
                    </fieldset>
                    <fieldset class="form-group">
                        <label for="exampleInputzipcode">Zip Code</label>
                        <input type="text" class="form-control" id="exampleInputzipcode" placeholder="Enter Country" value="{{ $users->zip_code }}" name="zip_code">
                    </fieldset>
                    <fieldset class="form-group">
                        <label for="exampleInputprofileImg">Profile Image</label>
                        <input type="file" class="form-control" id="exampleInputprofileImg" name="profile_img" accept="image/png, image/gif, image/jpeg">
                    </fieldset>
                </div>
            <div class="tab-pane fade" id="ex1-tabs-2" role="tabpanel" aria-labelledby="ex1-tab-2">
                <h4>Security Setting:</h4>
                <fieldset class="form-group">
                    <label for="exampleInputoldPassword">Old Password</label>
                    <input type="password" class="form-control" id="exampleInputoldPassword" placeholder="Enter Old Password" name="old_password"  autocomplete="off">
                    <small class="text-muted">If You want to Change Password than Provide Old Password Or If you want other changes you don't require password</small>
                </fieldset>
                <fieldset class="form-group">
                    <label for="exampleInputnewPassword">New Password</label>
                    <input type="password" class="form-control" id="exampleInputnewPassword" placeholder="Enter New Password" name="password">
                </fieldset>
                <fieldset class="form-group">
                    <label for="exampleInputsecretquestion">Secret Question</label>
                    <input type="text" class="form-control" id="exampleInputsecretquestion" placeholder="Enter Secret Question" name="secret_question">
                </fieldset>
                <fieldset class="form-group">
                    <label for="exampleInputsecretanswer">Secret Question's Answer</label>
                    <input type="text" class="form-control" id="exampleInputsecretanswer" placeholder="Enter Secret Question's Answer" name="secret_answer">
                </fieldset>
                <fieldset class="form-group">
                    <label for="eexampleSelectpv">Profile Visibility</label>
                    <select class="form-control color-black" id="eexampleSelectpv" name="profile_visibility">
                        <option value="public" {{ $users->profile_visibility == 'public'?'selected':'' }}>Public</option>
                        <option value="friends-of-friend" {{ $users->profile_visibility == 'friends-of-friend'?'selected':'' }}>Friends of Friend</option>
                        <option value="friends-only" {{ $users->profile_visibility == 'friends-only'?'selected':'' }}>Friends Only</option>
                        <option value="private" {{ $users->profile_visibility == 'private'?'selected':'' }}>No One</option>
                    </select>
                </fieldset>
                <fieldset class="form-group">
                    <label for="exampleSelectps">Profile Visibility</label>
                    <select class="form-control color-black" id="exampleSelectps" name="profile_status">
                        <option value="online" {{ $users->profile_status == 'online'?'selected':'' }}>Online</option>
                        <option value="offline" {{ $users->profile_status == 'offline'?'selected':'' }}>Offline</option>
                    </select>
                </fieldset>
            </div>
            <div class="tab-pane fade" id="ex1-tabs-3" role="tabpanel" aria-labelledby="ex1-tab-3">
                <h4>Details:</h4>
                <fieldset class="form-group">
                    <label for="exampleInputbio">Secret Question's Answer</label>
                    <textarea class="form-control" cols="6" rows="6" id="exampleInputbio" placeholder="Add Bio Description" name="bio_description">{{ $users->bio_description }}</textarea>
                </fieldset>
                <fieldset class="form-group show_education">
                    <label for="exampleSelecteducation">Education</label>
                    @foreach($users->education as $education)
                    <div class="card bg-dark">
                        <div class="card-body">
                            <div class="d-flex">
                                <h4 class="card-title eduname"><i class="fa fa-user-graduate me-2"></i>{{$education->name}}</h4>
                                <div class="float-end m-auto text-end">
                                    <span class="cursor-pointer" data-edu-id="{{ $education->id }}" onclick="educationEdit(this)"><i class="fa fa-pencil"></i></span>
                                    <span><i class="fa fa-pencil"></i></span>
                                </div>
                            </div>
                            <p class="card-text education_posi">
                                <span class="dg_title">{{$education->degree_title}}</span>
                                <span class="dg_name">{{ $education->degree_name }}</span>
                            </p>
                            <span class="education_detail">
                            <p class="card-text dg_address" data-country="{{ $education->country }}" data-state="{{ $education->state }}" data-city="{{ $education->city }}" data-zipcode="{{ $education->zipcode }}"><i class="fa fa-map-marker-alt me-2"></i>{{ $education->address }}</p>
                            </span>
                        </div>
                    </div>
                    @endforeach
                </fieldset>
                <div class="row add_education d-none">
                    <h6 class="text-danger error"></h6>
                    <div class="col-6">    
                    <fieldset class="form-group">
                        <label for="degree_title">Degree Title:</label>
                        <select name="degree_title" id="degree_title" class="form-control">
                            <option value="">Degree Title</option>
                            <option value="A-level">A/Level</option>
                            <option value="O-level">O/Level</option>
                            <option value="SSC">SSC</option>
                            <option value="HSC">HSC</option>
                            <option value="Bs">Bs</option>
                            <option value="BE">BE</option>
                            <option value="Ms">Ms</option>
                            <option value="ME">ME</option>
                            <option value="diploma">Diploma</option>
                        </select>
                    </fieldset>
                    </div>
                    <div class="col-6">
                    <fieldset class="form-group">
                        <label for="degree_name">Degree Name</label>
                        <input type="text" name="edu_name" class="form-control" id="edu_name" value="" placeholder="Degree Name">
                    </fieldset>
                    </div>
                    <div class="col-6">
                    <fieldset class="form-group">
                        <label for="edu_uni_name">College/University Name</label>
                        <input type="text" class="form-control" name="edu_uni_name" id="edu_uni_name" value="" placeholder="Degree Name">
                    </fieldset>
                    </div>
                    <div class="col-6">
                    <fieldset class="form-group">
                        <label for="edu_country">Country</label>
                        <input type="text" class="form-control" name="edu_country" id="edu_country" value="" placeholder="Country">
                    </fieldset>
                    </div>
                    <div class="col-6">
                    <fieldset class="form-group">
                        <label for="edu_state">State</label>
                        <input type="text" class="form-control" name="edu_state" id="edu_state" value="" placeholder="State">
                    </fieldset>
                    </div>
                    <div class="col-6">
                    <fieldset class="form-group">
                        <label for="edu_city">City</label>
                        <input type="text" class="form-control" name="edu_city" id="edu_city" value="" placeholder="City">
                    </fieldset>
                    </div>
                    <div class="col-6">
                    <fieldset class="form-group">
                        <label for="edu_address">Address</label>
                        <input type="text" class="form-control" name="edu_address" id="edu_address" value="" placeholder="Address">
                    </fieldset>
                    </div>
                    <div class="col-6">
                    <fieldset class="form-group">
                        <label for="edu_zipcode">Zipcode</label>
                        <input type="text" class="form-control" name="edu_zipcode" id="edu_zipcode" value="" placeholder="Zipcode">
                    </fieldset>
                    </div>
                    <div class="col-12">
                        <button type="button" id="addEducation" class="btn btn-secondary w-100 mt-4 mb-4">ADD</button>
                        <button type="button" id="editEducation" class="btn btn-secondary w-100 mt-4 mb-4 d-none">Update</button>
                    </div>
                </div>
                <button type="button" class="btn btn-primary" onclick="$('.add_education').toggleClass('d-none'); $('#editEducation').addClass('d-none')">Add Education</button>
            </div>
                <button type="submit" class="btn green_btn mt-3">Update</button>
            </form>
        </div>
        
    </div>
</div>
<script>
    $('a[data-mdb-toggle="tab"]').click(function() {
        $('.nav-link').removeClass('active')
        $(this).addClass('active');
        $('.tab-pane').removeClass(['show','active'])
        $(`div${$(this).attr('href')}`).addClass(['show','active'])
        /* Act on the event */
        // alert();
    });

    $('button#addEducation').click(function() {
        // alert()
        let degree_title = $('select[name="degree_title"]').val();
        let degree_name = $('input[name="edu_name"]').val();
        let college_name = $('input[name="edu_uni_name"]').val();
        let edu_country = $('input[name="edu_country"]').val();
        let edu_state = $('input[name="edu_state"]').val();
        let edu_city = $('input[name="edu_city"]').val();
        let edu_address = $('input[name="edu_address"]').val();
        let edu_zipcode = $('input[name="edu_zipcode"]').val();

        if(degree_title == '' || degree_title == undefined)
        {
            $('.error').html('Enter Degree Title');
            return false;
        }
        if(degree_name == '' || degree_name == undefined)
        {
            $('.error').html('Enter Degree Name');
            return false;
        }
        if(college_name == '' || college_name == undefined)
        {
            $('.error').html('Enter College Name');
            return false;
        }

        $.ajax({
            url: `{{route('addEducation', Auth::user()->id)}}`,
            type: 'POST',
            headers: {'X-CSRF-Token': '{{ csrf_token() }}'},
            data: {degree_title: degree_title, degree_name: degree_name, college_name: college_name, edu_country: edu_country, edu_state: edu_state, edu_city, edu_city, edu_address: edu_address, edu_zipcode: edu_zipcode, type: 'education', position: 'student'},
        })
        .done(function(resp) {
            let html = `<div class="card bg-dark">
                        <div class="card-body">
                            <div class="d-flex">
                                <h4 class="card-title eduname"><i class="fa fa-user-graduate me-2"></i>${college_name}</h4>
                                <div class="float-end m-auto text-end">
                                    <span class="cursor-pointer" data-edu-id="${resp.id}" onclick="educationEdit(this)"><i class="fa fa-pencil"></i></span>
                                    <span><i class="fa fa-pencil"></i></span>
                                </div>
                            </div>
                            <p class="card-text education_posi">
                                <span class="dg_title">${degree_title}</span>
                                <span class="dg_name">${degree_name}</span>
                            </p>
                            <span class="education_detail">
                            <p class="card-text dg_address" data-country="${resp.education.country}" data-state="${resp.education.state}" data-city="${resp.education.city}" data-zipcode="${resp.education.zipcode}"><i class="fa fa-map-marker-alt me-2"></i>${edu_address}</p>
                            </span>
                        </div>
                    </div>`;
            $('.show_education').append(html);
            $('.add_education input').val('');
            $('.add_education').toggleClass('d-none');
        })
        .fail(function() {
            console.log("error");
        })
        .always(function() {
            console.log("complete");
        });
        
    });

    function educationEdit(data) {

        let eduId = $(data).attr('data-edu-id');
        let parent = $(data).parents('div.card');
        let college_name = $(parent).find('h4.eduname').text();
        let degree_title = $(parent).find('span.dg_title').text();
        let degree_name = $(parent).find('span.dg_name').text();
        let degree_address = $(parent).find('p.dg_address').text();
        let country = $(parent).find('p.dg_address').attr('data-country');
        let state = $(parent).find('p.dg_address').attr('data-state');
        let city = $(parent).find('p.dg_address').attr('data-city');
        let zipcode = $(parent).find('p.dg_address').attr('data-zipcode');
        $(data).parents('div.card').remove();
        $('select[name="degree_title"] option').each((index, value)=>{
            let opt_text = $(value).text();
            if(opt_text.toLowerCase() === degree_title.toLowerCase()){
                $(value).attr('selected','selected')
            }
        })
        $('input[name="edu_name"]').val(degree_name)
        $('input[name="edu_uni_name"]').val(college_name);
        $('input[name="edu_country"]').val(country)
        $('input[name="edu_state"]').val(state)
        $('input[name="edu_city"]').val(city)
        $('input[name="edu_address"]').val(degree_address)
        $('input[name="edu_zipcode"]').val(zipcode)
        $('#editEducation').attr('data-edu-id', eduId)
        $('.add_education').toggleClass('d-none');
        $('#addEducation').addClass('d-none')
        $('#editEducation').removeClass('d-none')
        // console.log(eduId,college_name,degree_title,degree_name,degree_address);
        // body...
    }

    $('button#editEducation').click(function() {
        // alert()
        // console.log($(this).attr('data-edu-id'))
        // return false;
        let degree_title = $('select[name="degree_title"]').val();
        let degree_name = $('input[name="edu_name"]').val();
        let college_name = $('input[name="edu_uni_name"]').val();
        let edu_country = $('input[name="edu_country"]').val();
        let edu_state = $('input[name="edu_state"]').val();
        let edu_city = $('input[name="edu_city"]').val();
        let edu_address = $('input[name="edu_address"]').val();
        let edu_zipcode = $('input[name="edu_zipcode"]').val();

        if(degree_title == '' || degree_title == undefined)
        {
            $('.error').html('Enter Degree Title');
            return false;
        }
        if(degree_name == '' || degree_name == undefined)
        {
            $('.error').html('Enter Degree Name');
            return false;
        }
        if(college_name == '' || college_name == undefined)
        {
            $('.error').html('Enter College Name');
            return false;
        }

        $.ajax({
            url: `update-education/{{Auth::user()->id}}/${$(this).attr('data-edu-id')}`,
            type: 'POST',
            headers: {'X-CSRF-Token': '{{ csrf_token() }}'},
            data: {degree_title: degree_title, degree_name: degree_name, college_name: college_name, edu_country: edu_country, edu_state: edu_state, edu_city, edu_city, edu_address: edu_address, edu_zipcode: edu_zipcode, type: 'education', position: 'student'},
        })
        .done(function(resp) {
            let html = `<div class="card bg-dark">
                        <div class="card-body">
                            <div class="d-flex">
                                <h4 class="card-title eduname"><i class="fa fa-user-graduate me-2"></i>${college_name}</h4>
                                <div class="float-end m-auto text-end">
                                    <span class="cursor-pointer" data-edu-id="${resp.id}" onclick="educationEdit(this)"><i class="fa fa-pencil"></i></span>
                                    <span><i class="fa fa-pencil"></i></span>
                                </div>
                            </div>
                            <p class="card-text education_posi">
                                <span class="dg_title">${degree_title}</span>
                                <span class="dg_name">${degree_name}</span>
                            </p>
                            <span class="education_detail">
                            <p class="card-text dg_address" data-country="${resp.education.country}" data-state="${resp.education.state}" data-city="${resp.education.city}" data-zipcode="${resp.education.zipcode}"><i class="fa fa-map-marker-alt me-2"></i>${edu_address}</p>
                            </span>
                        </div>
                    </div>`;
            $('.show_education').append(html);
            $('.add_education input').val('');
            $('.add_education').toggleClass('d-none');
        })
        .fail(function() {
            console.log("error");
        })
        .always(function() {
            console.log("complete");
        });
        
    });
</script>
@endsection
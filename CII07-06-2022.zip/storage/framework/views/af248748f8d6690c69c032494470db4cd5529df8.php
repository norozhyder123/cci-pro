
<?php $__env->startSection('content'); ?>
        <section class="page_banner">
            <h3 class="heading_3 position-relative">Contact Us</h3>
        </section>
        <section>
            <div class="contact-form-wrapper ">
                <?php if(Session::has('msg')): ?>
                        <div class="alert alert-success text-center">
                            <p><?php echo e(Session::get('msg')); ?></p>
                        </div>
                    <?php endif; ?>
                <form action="<?php echo e(route('contact.submit')); ?>" method="post" class="contact-form mx-auto">
                    <?php echo csrf_field(); ?>
                    <h5 class="heading_3 text-center mb-4">Contact Us</h5>
                    <p class="paragraph_medium text-center mb-3">
                        Got any questions? Submit your query and our representatives will get back to you at the earliest!
                    </p>
                    <div>
                        <input type="text" class="form-control rounded mb-3 form-input" name="name" value="<?php echo e(Auth::user()? Auth::user()->getFullName(): ''); ?>" id="name" placeholder="Name" required <?php echo e(Auth::user()?'readonly':''); ?>>
                    </div>
                    <div>
                        <input type="email" class="form-control rounded mb-3 form-input" name="email" value="<?php echo e(Auth::user()? Auth::user()->email: ''); ?>" placeholder="Email" required <?php echo e(Auth::user()?'readonly':''); ?>>
                    </div>
                    <div>
                        <textarea id="message" class="form-control rounded mb-3 form-text-area" name="message" rows="5" cols="30" placeholder="Message" required></textarea>
                    </div>
                    <div class="d-flex justify-content-center">
                        <button class="green_btn" type="submit">Send</button>
                    </div>
                </form>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\CII\resources\views/front/contact.blade.php ENDPATH**/ ?>
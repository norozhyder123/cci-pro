
<?php $__env->startSection('content'); ?>
<div class="col-lg-9 col-md-12 col-sm-12 px-0">
    <div class="forum_right font_family--kanit mb-3">
        <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="text_size-24 text_color--green">Forums</div>
        </div>
    <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-8 mx-auto pb-4">
        <div class="card border-secondary" style="background: #fbfbfb3b">
          <div class="card-header">
            <?php echo e($bb->user->getFullName()); ?>

          </div>
          <div class="card-body">
            <p class="card-text">
                <?php echo $bb->blog; ?> 
            </p>
          </div>
          <div class="card-footer text-muted">
            <div class="d-flex row">
                <div class="col-4">
                    <?php if(! auth()->guard('admin')): ?>
                    <form action="<?php echo e(route('blogLike', $bb->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="slug" value="<?php echo e($bb->slug); ?>">
                        <button type="submit" class="btn btn-primary">
                            <span><i class="fa fa-thumbs-up"></i> <?php echo e(count($bb->blogLikes)); ?></span>
                        </button>
                    </form>
                    <?php else: ?>
                    <button class="btn btn-primary">
                            <span><i class="fa fa-thumbs-up"></i> <?php echo e(count($bb->blogLikes)); ?></span>
                    </button>
                    <?php endif; ?>
                </div>
                <div class="col-4">
                    <button class="btn">
                        <span><i class="fa fa-comment"></i> <?php echo e(count($bb->commentsCount)); ?></span>
                    </button>
                </div>
                <div class="col-4">
                    <span><i class="fa fa-eye"></i> <?php echo e(count($bb->blogViews)); ?></span>
                </div>
                <div class="col-12">
                    <div class="card">
                        <?php 
                        $countComm = 0;
                        ?>
                        <?php $__currentLoopData = $bb->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-body comments <?php echo e($countComm>0?'d-none':'deff'); ?>">
                            <?php if(!empty($comment->user->profile_img)): ?>
                            <img class="card-img-top rounded-circle" style="width:40px; height:40px;" src="<?php echo e(asset('storage/'.$comment->user->profile_img)); ?>" alt="Card image cap">
                            <?php endif; ?>
                            <h4 class="card-title d-inline-flex p-1"><?php echo e($comment->user->first_name); ?></h4>
                            <p class="card-text" style="margin-left: 45px; margin-top: -13px;"><?php echo e($comment->comment); ?></p>
                            <?php if(! auth()->guard('admin')): ?>
                            <button onclick="$(this).parent().find('form').toggleClass('d-none');">
                                <span><i class="fa fa-share"></i> <?php echo e(count($comment->subcomment)); ?></span>
                            </button>
                            <?php endif; ?>
                            <form action="<?php echo e(route('blogComment', $bb->id)); ?>" method="post" class="d-none">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="slug" value="<?php echo e($bb->slug); ?>">
                                <input type="hidden" name="parent_comment_id" value="<?php echo e($comment->id); ?>">
                                <fieldset class="form-group">
                                    <label for="comment">Comment</label>
                                    <textarea id="comment" class="form-control" rows="6" cols="6" name="comment" required=""></textarea>
                                    <small class="text-muted">Your comment will be open with anyone else.</small>
                                </fieldset>
                                <button type="submit" class="btn btn-primary">
                                    <span><i class="fa fa-comment"></i> <?php echo e(count($comment->subcomment)); ?></span>
                                </button>
                            </form>

                            <?php if(count($comment->subcomment) > 0): ?>
                            <?php 
                            $subComments = $comment->subcomment;
                            ?>
                            <?php echo e(view('user.dashboard.blogs.subComments', compact('subComments', 'bb'))); ?>

                            <?php endif; ?>
                        </div>
                        <?php ++$countComm; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($countComm > 0): ?>
                            <button class="showall" onclick="ShowAll(this)">Show All</button>
                            <button class="showless d-none" onclick="ShowLess(this)">Show Less</button>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="col-12 d-none" id="commentDiv">
                    <form action="<?php echo e(route('blogComment', $bb->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="slug" value="<?php echo e($bb->slug); ?>">
                        <fieldset class="form-group">
                            <label for="comment">Comment</label>
                            <textarea id="comment" class="form-control" rows="6" cols="6" name="comment" required=""></textarea>
                            <small class="text-muted">Your comment will be open with anyone else.</small>
                        </fieldset>
                        <button type="submit" class="btn btn-primary">Comment</button>
                    </form>
                </div>
            </div>
          </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<script>
    function ShowLess(data) {

        $('.card-body.comments').addClass('d-none');
        $('.card-body.comments.deff').removeClass('d-none');
        $(data).addClass('d-none')
        $('.showall').removeClass('d-none')
        // body...
    }

    function ShowAll(data) {

        $('.card-body.comments.d-none').removeClass('d-none');
        $(data).addClass('d-none')
        $('.showless').removeClass('d-none')
        // body...
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\CII\resources\views/admin/adminView/forums.blade.php ENDPATH**/ ?>
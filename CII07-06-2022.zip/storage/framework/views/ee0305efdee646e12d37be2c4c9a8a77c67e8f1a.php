
<?php $__env->startSection('content'); ?>
<div class="col-lg-9 col-md-12 col-sm-12 ps-3">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <div class="text_size-24 font_weight--500">Connections</div>
    </div>
    <div class="mb-3 you_know ms-2 p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="text_size-16 font_weight--500">People you may know</div>
        </div>
        <div class="row people_you-know justify-content-start mb-2">
            <?php $__currentLoopData = $connections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3 connectivity px-0 m-2">
                <?php if(!empty($connection->profile_img)): ?>
                <img src="<?php echo e(asset('storage/'.$connection->profile_img)); ?>" class="w-100" alt="">
                <?php else: ?>
                <img src="<?php echo e(asset('assets/images/person_1.png')); ?>" class="w-100" alt="">
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center px-2 my-2 w-100">
                    <div class="text_size-12"><?php echo e($connection->first_name.' '.$connection->last_name); ?></div>
                    <img src="<?php echo e(asset('assets/images/Iconly-Bulk-Send.png')); ?>" alt="" data-url="<?php echo e(route('send.request', $connection->id)); ?>" onclick="sendRequest(<?php echo e($connection->id); ?>, this)">
                </div>
                <div class="text_size-12 font_color-black font_weight--300 px-2 mb-3">
                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                </div>
                <a class="green_profile-btn text-center" href="<?php echo e(route('connectionProfile', $connection->id)); ?>">View Profile</a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="mb-3 you_know ms-2 p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="text_size-16 font_weight--500">My Connections</div>
        </div>
        <div class="row people_you-know justify-content-start mb-2">
            <?php $__currentLoopData = $connected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3 connectivity px-0 m-2">
                <?php if(!empty($connect->profile_img)): ?>
                <img src="<?php echo e(asset('storage/'.$connect->profile_img)); ?>" class="w-100" alt="">
                <?php else: ?>
                <img src="<?php echo e(asset('assets/images/person_1.png')); ?>" class="w-100" alt="">
                <?php endif; ?>
                    <div class="p-2">
                        <div class="text_size-12"><?php echo e($connect->first_name.' '.$connect->last_name); ?></div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center px-2 my-2 w-100">
                        <?php
                            $req_status = App\Models\UserRequest::select('status as requestStatus')->where('user_id', $connect->id)->orWhere('to_id', $connect->id)->first();
                            ?>
                    <?php if($req_status->requestStatus == 'waiting'): ?>
                    <small class="text-capitalize">Waiting For Approval</small>
                    <?php else: ?>
                    <small class="text-capitalize"><?php echo e($req_status->requestStatus); ?></small>
                    <?php endif; ?>
                </div>
                <div class="text_size-12 font_color-black font_weight--300 px-2 mb-3">
                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                </div>
                <button class="green_profile-btn">View Profile</button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="mb-3 you_know ms-2 p-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="text_size-16 font_weight--500">My Incoming Requests</div>
        </div>
        <div class="row people_you-know justify-content-start mb-2">
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3 connectivity px-0 m-2">
                <?php if(!empty($connect->profile_img)): ?>
                <img src="<?php echo e(asset('storage/'.$connect->profile_img)); ?>" class="w-100" alt="">
                <?php else: ?>
                <img src="<?php echo e(asset('assets/images/person_1.png')); ?>" class="w-100" alt="">
                <?php endif; ?>
                <div class="p-2">
                    <div class="text_size-12"><?php echo e($connect->first_name.' '.$connect->last_name); ?></div>
                </div>
                    <div class="d-flex justify-content-between align-items-center px-2 my-2 w-100">
                    <?php if($connect->requestStatus == 'waiting'): ?>
                    <button class="green_profile-btn" data-url="<?php echo e(route('approve.request', $connect->id)); ?>" onclick="approveRequest(<?php echo e($connect->id); ?>, this)">Approve</button>
                    <button class="green_profile-btn" data-url="<?php echo e(route('reject.request', $connect->id)); ?>" onclick="rejectRequest(<?php echo e($connect->id); ?>, this)">Reject</button>

                    <?php else: ?>
                    <small><?php echo e($connect->requestStatus); ?></small>
                    <?php endif; ?>
                </div>
                <div class="text_size-12 font_color-black font_weight--300 text-center px-2 mb-3">
                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                </div>
                <button class="green_profile-btn">View Profile</button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script>
    function sendRequest(id, data) {
        $.ajax({
                url: `${$(data).attr('data-url')}`,
                type: 'GET',
                data: {
                    from_id: id
                },
            })
            .done(function(resp) {
                $(data).parents('.connectivity').remove();
                console.log(resp);
                console.log("success");
            })
            .fail(function() {
                console.log("error");
            })
            .always(function() {
                console.log("complete");
            });

    }

    function approveRequest(id, data) {
        $.ajax({
                url: `${$(data).attr('data-url')}`,
                type: 'GET',
                data: {
                    from_id: id
                },
            })
            .done(function(resp) {
                $(data).parents('.connectivity').remove();
                console.log(resp);
                console.log("success");
            })
            .fail(function() {
                console.log("error");
            })
            .always(function() {
                console.log("complete");
            });

    }

    function rejectRequest(id, data) {
        $.ajax({
                url: `${$(data).attr('data-url')}`,
                type: 'GET',
                data: {
                    from_id: id
                },
            })
            .done(function(resp) {
                $(data).parents('.connectivity').remove();
                console.log(resp);
                console.log("success");
            })
            .fail(function() {
                console.log("error");
            })
            .always(function() {
                console.log("complete");
            });

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\CII\resources\views/user/dashboard/connections.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
            <div class="col-lg-9 col-md-12 col-sm-12 ps-3">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="text_size-24 font_weight--500">All Users</div>
                            <div class="paragraph_medium text_color--green font_weight--500">Expand</div>
                        </div>
                        <div class="stock_update mb-3">
                            <table class="table table-responsive text-white">
                                <thead>
                                    <tr>
                                        <th>S.No#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count = 0; ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $count++; ?>
                                    <tr>
                                        <td><?php echo e($count); ?></td>
                                        <td><?php echo e($user->getFullName()); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->phone); ?></td>
                                        <td><?php echo e($user->status); ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                            <a href="<?php echo e(route('admin.users.edit',['id' => $user->id])); ?>"><i class="fa fa-pencil"></i></a>
                                            
                                            <form action="<?php echo e(route('admin.users.delete',['id' => $user->id])); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn bg-transparent text-danger"><i class="fa fa-trash"></i></button>
                                            </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\CII\resources\views/admin/adminView/users.blade.php ENDPATH**/ ?>
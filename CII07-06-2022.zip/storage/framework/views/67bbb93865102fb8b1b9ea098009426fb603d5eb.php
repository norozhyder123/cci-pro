<div class="row d-flex">
	<div class="col-12">
		<div class="card">
		<?php $__currentLoopData = $subComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card-body">
				<?php if(!empty($subComment->comment->user->profile_img)): ?>
				<img class="card-img-top rounded-circle" style="width:40px; height:40px;" src="<?php echo e(asset('storage/'.$subComment->comment->user->profile_img)); ?>" alt="Card image cap">
				<?php endif; ?>
				<h4 class="card-title d-inline-flex p-1"><?php echo e($subComment->comment->user->first_name); ?></h4>
				<p class="card-text" style="margin-left: 45px; margin-top: -13px;"><?php echo e($subComment->comment->comment); ?></p>
				<?php if(! auth()->guard('admin')): ?>
				<button onclick="$(this).parent().find('form').toggleClass('d-none');">
					<span><i class="fa fa-share"></i> <?php echo e(count($subComment->comment->subcomment)); ?></span>
				</button>
				<?php endif; ?>
				<form action="<?php echo e(route('blogComment', $bb->id)); ?>" method="post" class="d-none">
	    			<?php echo csrf_field(); ?>
	    			<input type="hidden" name="slug" value="<?php echo e($bb->slug); ?>">
	    			<input type="hidden" name="parent_comment_id" value="<?php echo e($subComment->comment->id); ?>">
	    			<fieldset class="form-group">
		    			<label for="comment">Comment</label>
		    			<textarea id="comment" class="form-control" rows="6" cols="6" name="comment" required=""></textarea>
						<small class="text-muted">Your comment will be open with anyone else.</small>
					</fieldset>
	    			<button type="submit" class="btn btn-primary">
	    				<span><i class="fa fa-comment"></i> <?php echo e(count($subComment->comment->subcomment)); ?></span>
	    			</button>
	    		</form>
	    		<?php if(count($subComment->comment->subcomment) > 0): ?>
	    		<?php 
	    		$subComments = $subComment->comment->subcomment;
	    		?>
	    		<?php echo e(view('user.dashboard.blogs.subComments', compact('subComments', 'bb'))); ?>

	    		<?php endif; ?>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div><?php /**PATH E:\laragon\www\CII\resources\views/user/dashboard/blogs/subComments.blade.php ENDPATH**/ ?>